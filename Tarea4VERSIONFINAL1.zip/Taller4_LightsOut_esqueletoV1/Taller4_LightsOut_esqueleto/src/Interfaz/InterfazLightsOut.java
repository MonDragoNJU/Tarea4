package Interfaz;

import java.awt.BorderLayout;
import java.io.File;
import javax.swing.JFrame;
import uniandes.dpoo.taller4.modelo.Tablero;
import uniandes.dpoo.taller4.modelo.Top10;


public class InterfazLightsOut extends JFrame{
	
	//Attributes//
	
	private PanelDificultad paneldificultad;
	private PanelBotones panelBotones;
	private PanelJugadas panelJugadas;
	private PanelTablero panelTablero;
	private Tablero tablero;
	private Top10 top10;
	private static final File archivo = new File("data/top10.csv");
	
	 
	public InterfazLightsOut(){
		
		this.paneldificultad = new PanelDificultad(this);
		this.panelBotones = new PanelBotones(this);
		this.panelJugadas = new PanelJugadas(this);
		this.panelTablero = new PanelTablero(this, 1);
		this.top10 = new Top10();
		top10.cargarRecords(archivo);
		
		setTitle("LightsOut");
		setSize(478, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		BorderLayout bl = new BorderLayout();
		setLayout(bl);	
		
		add(paneldificultad, BorderLayout.NORTH);
		add(panelBotones, BorderLayout.EAST);
		add(panelJugadas, BorderLayout.SOUTH);
		add(panelTablero);
		
		
		setVisible(true);
	}
	
	//Getters//
	public Tablero getTablero() {
		return this.tablero;
	}
	
	//Metodos//
	
	public void nuevo() {
		int tamanioSeleccionado = paneldificultad.getTamanioSeleccionado();
		int dificultadSeleccionada = paneldificultad.getDificultad();
		this.tablero = new Tablero(tamanioSeleccionado);
		panelTablero.setTamañoTablero(tamanioSeleccionado);
		tablero.desordenar(dificultadSeleccionada);
		panelJugadas.cambiarEditable(false);
		panelTablero.repaint();
		
	}
	
	//Cuando termine de poner el nombre del jugador, solo presione la tecla enter para que se guarde//
	public void cambiarJugador(){
		panelJugadas.cambiarEditable(true);
	}
	
	public void reiniciar() {
		tablero.reiniciar();
	}
	
	public void aumentarJugadas() {
		int jugaditas = tablero.darJugadas();
		panelJugadas.setNumJugadas(jugaditas);
	}
	
	public void revisarGanador() {
		if (tablero.tableroIluminado()) {
			int puntajeFinal = tablero.calcularPuntaje();
			
		}
	}
	
	public void top10() {
		new JDialogTop10();
	}
	
 
	public static void main(String[] args){
		InterfazLightsOut interfaz = new InterfazLightsOut();
	}

}
