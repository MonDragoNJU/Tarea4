package Interfaz;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;

public class PanelBotones extends JPanel implements ActionListener{
	
	private InterfazLightsOut interfaz;
	
	public PanelBotones(InterfazLightsOut interfaz) {
		this.interfaz = interfaz;
		
		setLayout(new GridBagLayout());
		
		JButton nuevoButton = new JButton("NUEVO");
		JButton reiniciarButton = new JButton("REINICIAR");
        JButton top10Button = new JButton("TOP-10");
        JButton cambiarJugadorButton = new JButton("CAMBIAR JUGADOR");
        
        //Cambiar color
        Color colorAzulClaro = new Color(7, 137, 245);
        nuevoButton.setBackground(colorAzulClaro);
        nuevoButton.setForeground(Color.WHITE);
        reiniciarButton.setBackground(colorAzulClaro);
        reiniciarButton.setForeground(Color.WHITE);
        top10Button.setBackground(colorAzulClaro);
        top10Button.setForeground(Color.WHITE);
        cambiarJugadorButton.setBackground(colorAzulClaro);
        cambiarJugadorButton.setForeground(Color.WHITE);
        
        
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(10, 10, 10, 10);

        gbc.gridx = 0;
        gbc.gridy = 0;
        add(nuevoButton, gbc);

        gbc.gridy = 1;
        add(reiniciarButton, gbc);

        gbc.gridy = 2;
        add(top10Button, gbc);

        gbc.gridy = 3;
        add(cambiarJugadorButton, gbc);
        
        nuevoButton.setActionCommand("NUEVO");
        nuevoButton.addActionListener(this);
        
        reiniciarButton.setActionCommand("REINICIAR");
        reiniciarButton.addActionListener(this);
        
        top10Button.setActionCommand("TOP10");
        top10Button.addActionListener(this);
       
        cambiarJugadorButton.setActionCommand("CAMBIAR");
        cambiarJugadorButton.addActionListener(this);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		String llamado = e.getActionCommand();
		if (llamado.equals("NUEVO")) {
			interfaz.nuevo();
		}
		else if (llamado.equals("REINICIAR")) {
			interfaz.reiniciar();

		}
		else if (llamado.equals("TOP10")) {
			interfaz.top10();

		}
		else {
			interfaz.cambiarJugador();

		}
		
	}

}
