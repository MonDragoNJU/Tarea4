package Interfaz;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelJugadas extends JPanel{
	
	private JTextField numJugadas;
	private JTextField nombreJugador;
	private InterfazLightsOut interfaz;
	
	public PanelJugadas(InterfazLightsOut interfaz) {
		this.interfaz = interfaz;
		this.numJugadas = new JTextField("0");
		this.numJugadas.setEditable(false);
		
		this.nombreJugador = new JTextField();
		this.nombreJugador.setEditable(true);
		
		nombreJugador.setColumns(8);
		numJugadas.setColumns(8);
		
		JLabel jugadas = new JLabel("Jugadas:");
		JLabel jugador = new JLabel("Jugador:");
		
		nombreJugador.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // Verifica si la tecla presionada fue Enter
                if (e.getModifiers() == 0) {
                    nombreJugador.setEditable(false);
                    System.out.println(nombreJugador.getText());
                }
            }
        });
	
		add(jugadas);
		add(numJugadas);
		add(jugador);
		add(nombreJugador);
		
	}
	
	public void setNumJugadas(int num) {
		this.numJugadas.setText(String.valueOf(num));
	}
 
	public void cambiarEditable(boolean respuesta) {
		this.nombreJugador.setEditable(respuesta);
	}
	

}
