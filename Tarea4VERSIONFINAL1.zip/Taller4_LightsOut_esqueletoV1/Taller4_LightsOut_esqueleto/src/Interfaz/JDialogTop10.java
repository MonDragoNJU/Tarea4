package Interfaz;

import java.awt.BorderLayout;
import java.awt.Color;

import javax.swing.BorderFactory;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.JScrollPane;

import uniandes.dpoo.taller4.modelo.RegistroTop10;

public class JDialogTop10 extends JDialog{
	
	private static final Color gray = new Color(128, 128, 128);
	private JList<RegistroTop10> top = new JList<RegistroTop10>();
	
	public JDialogTop10(){
		JScrollPane panelScroll = new JScrollPane();
		panelScroll.setBackground(gray);
		panelScroll.setBorder(BorderFactory.createTitledBorder("# Nombre"));
		setVisible(true);
		
	}
}
