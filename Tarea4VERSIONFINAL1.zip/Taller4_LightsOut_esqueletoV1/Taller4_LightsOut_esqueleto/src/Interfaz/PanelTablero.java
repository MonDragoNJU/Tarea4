package Interfaz;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Arrays;

import javax.swing.JPanel;

import uniandes.dpoo.taller4.modelo.Tablero;

public class PanelTablero extends JPanel implements MouseListener{
	
	private static final Color gray = new Color(128, 128, 128);
	private int tamañoTablero;
	private int tamañoCasilla;
	private InterfazLightsOut interfaz;
	private int Xcoord;
	private int Ycoord;
	
	//Constructor//
	public PanelTablero(InterfazLightsOut interfaz, int tamañoTablero) {
		this.tamañoTablero = tamañoTablero;
		this.interfaz = interfaz;
		addMouseListener(this);
	}
	
	@Override
	public void paintComponent(Graphics g) {
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(new Color(7, 137, 245));
		
		int ancho = getSize().width;
		int alto = getSize().height;
		
		g2d.fillRect(0, 0, ancho, alto);
		
		tamañoCasilla = ((alto / tamañoTablero) + (ancho / tamañoTablero)) / 2; 
		int i = 0;
		while(i < tamañoTablero) {
			int x = i * tamañoCasilla;
			int j = 0;
			while(j < tamañoTablero) {
				int y = j * tamañoCasilla;
				g2d.setColor(gray);
				if (revisarEstadoCasilla(i, j)) {
					g2d.setColor(new Color(255, 255, 153));
				}
				g2d.fillRect(x, y, tamañoCasilla, tamañoCasilla);
				
				g2d.setColor(Color.BLACK);
		        g2d.drawRect(x, y, tamañoCasilla, tamañoCasilla);
		        
		        j++;
			}
			i++;
		}
	}
	
	private int[] convertirCoordenadasACasilla(int Xcoord, int Ycoord) {
		int i = Xcoord / tamañoCasilla;
	    int j = Ycoord / tamañoCasilla;
	    
	    if (i >= 0 && i < tamañoTablero && j >= 0 && j < tamañoTablero) {
	        int x1 = i * tamañoCasilla;
	        int x2 = x1 + tamañoCasilla;
	        int y1 = j * tamañoCasilla;
	        int y2 = y1 + tamañoCasilla;

	        if (Xcoord >= x1 && Xcoord < x2 && Ycoord >= y1 && Ycoord < y2) {
	            return new int[] { i, j };
	        }
	    }
		return new int[] {-1, -1};
	}
	
	//Se necesita poder cambiar el tamanio del tablero en algun momento//
	public void setTamañoTablero(int tamañoTablero) {
		this.tamañoTablero = tamañoTablero;
	}
	
	public boolean revisarEstadoCasilla(int i, int j) {
		if (tamañoTablero == 1) {
			return true;
		}
		else {
			return interfaz.getTablero().darTablero()[i][j];
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		int x = e.getX();
		int y = e.getY();
		int[] casillas = convertirCoordenadasACasilla(x, y);
		if (casillas[0] != -1 && casillas[1] != -1 && tamañoTablero != 1) {
		    interfaz.getTablero().jugar(casillas[0], casillas[1]);
		    interfaz.aumentarJugadas();
		}
		repaint();
		
	}


	@Override
	public void mousePressed(MouseEvent e) {
		
	}


	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}
	


}
