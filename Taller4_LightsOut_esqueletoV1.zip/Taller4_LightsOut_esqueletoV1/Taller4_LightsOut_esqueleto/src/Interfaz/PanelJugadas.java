package Interfaz;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class PanelJugadas extends JPanel{
	
	private JTextField numJugadas;
	private JTextField nombreJugador;
	
	public PanelJugadas() {
		this.numJugadas = new JTextField("0");
		this.numJugadas.setEditable(false);
		
		this.nombreJugador = new JTextField();
		this.nombreJugador.setEditable(true);
		
		nombreJugador.setColumns(8);
		numJugadas.setColumns(8);
		
		JLabel jugadas = new JLabel("Jugadas:");
		JLabel jugador = new JLabel("Jugador:");
		
		add(jugadas);
		add(numJugadas);
		add(jugador);
		add(nombreJugador);
		
	}
	
	public void setNumJugadas(int num) {
		this.numJugadas.setText(String.valueOf(num));
	}
	

}
