package Interfaz;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;

import javax.swing.ButtonGroup;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

public class PanelDificultad extends JPanel{
	
	public PanelDificultad() {
		
		setPreferredSize(new Dimension(500, 35));
		String[] tamanios = {"3x3", "5x5", "7x7"};
		JComboBox<String> comboBox = new JComboBox<>(tamanios);
		JLabel etiquetaTamanio = new JLabel("Tamaño:");
		
		Color colorAzulClaro = new Color(7, 137, 245);
		setBackground(colorAzulClaro);
		etiquetaTamanio.setForeground(Color.WHITE);
		
		JLabel etiquetaDificultad = new JLabel("Dificultad:");
		etiquetaDificultad.setForeground(Color.WHITE);
		
		JRadioButton facil = new JRadioButton("Facil");
        JRadioButton medio = new JRadioButton("Medio");
        JRadioButton dificil = new JRadioButton("Dificil");
        
        //Cambiar el color
        facil.setBackground(colorAzulClaro);
        medio.setBackground(colorAzulClaro);
        dificil.setBackground(colorAzulClaro);
        facil.setForeground(Color.WHITE);
        medio.setForeground(Color.WHITE);
        dificil.setForeground(Color.WHITE);
        
        ButtonGroup group = new ButtonGroup();
        group.add(facil);
        group.add(medio);
        group.add(dificil);
        
        FlowLayout fl = new FlowLayout();
		setLayout(fl);
		
		add(etiquetaTamanio);
		add(comboBox);
		add(etiquetaDificultad);
		add(facil);
		add(medio);
		add(dificil);
	} 

}
