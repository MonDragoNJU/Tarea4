package Interfaz;

import java.awt.BorderLayout;
import java.io.IOException;

import javax.swing.JFrame;

import com.formdev.flatlaf.FlatLightLaf;

import uniandes.dpoo.taller4.modelo.Tablero;


public class InterfazLightsOut extends JFrame{
	
	private PanelDificultad paneldificultad;
	private PanelBotones panelBotones;
	private PanelJugadas panelJugadas;
	private PanelTablero panelTablero;
	
	
	public InterfazLightsOut(){
		
		this.paneldificultad = new PanelDificultad();
		this.panelBotones = new PanelBotones();
		this.panelJugadas = new PanelJugadas();
		this.panelTablero = new PanelTablero();
		
		setTitle("LightsOut");
		setSize(500, 400);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setLocationRelativeTo(null);
		
		BorderLayout bl = new BorderLayout();
		setLayout(bl);	
		
		add(paneldificultad, BorderLayout.NORTH);
		add(panelBotones, BorderLayout.EAST);
		add(panelJugadas, BorderLayout.SOUTH);
		add(panelTablero, BorderLayout.WEST);
		
		
		setVisible(true);
	}
	
	public static void main(String[] args){
		InterfazLightsOut interfaz = new InterfazLightsOut();
		FlatLightLaf.install();
	}

}
