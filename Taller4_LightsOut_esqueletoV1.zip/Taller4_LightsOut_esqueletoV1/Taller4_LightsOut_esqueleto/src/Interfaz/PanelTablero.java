package Interfaz;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import uniandes.dpoo.taller4.modelo.Tablero;

public class PanelTablero extends JPanel implements ActionListener{
	
	private int tamanio = 200;
	private int tamañoTablero = 5;
	private Tablero tablero = new Tablero(tamañoTablero);
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
        int casillaSize = 40; // Tamaño de las casillas (ajusta según tus necesidades)
        int separacion = 10; // Espacio entre las casillas (ajusta según tus necesidades)
        boolean[][] casillas = tablero.darTablero();

        int anchoTotal = tamanio * (casillaSize + separacion);
        int altoTotal = tamanio * (casillaSize + separacion);
        int xOffset = (getWidth() - anchoTotal) / 2;
        int yOffset = (getHeight() - altoTotal) / 2;

        for (int i = 0; i < tamañoTablero; i++) {
            for (int j = 0; j < tamañoTablero; j++) {
                if (casillas[i][j]) {
                    g.setColor(Color.YELLOW); // Color para casilla encendida
                } else {
                    g.setColor(Color.GRAY); // Color para casilla apagada
                }
                int x = xOffset + i * (casillaSize + separacion);
                int y = yOffset + j * (casillaSize + separacion);
                g.fillRect(x, y, casillaSize, casillaSize);
            }
        }
	}


	@Override
	public void actionPerformed(ActionEvent e) {
		
	}

}
